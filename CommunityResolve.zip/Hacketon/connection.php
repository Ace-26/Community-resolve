
<?php
$host = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "compdb";
$db = mysqli_connect($host, $dbuser, $dbpass, $dbname);
